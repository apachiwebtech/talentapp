// logger.js
const fs = require('fs');
const path = require('path');

// Log directory
const logPath = path.join(__dirname, 'logs');
if (!fs.existsSync(logPath)) {
  fs.mkdirSync(logPath);
}

// Append log to file
function logToFile(message, filename = 'app.log') {
  const logMessage = `[${new Date().toISOString()}] ${message}\n`;
  fs.appendFile(path.join(logPath, filename), logMessage, err => {
    if (err) console.error('Failed to write to log file:', err);
  });
}

module.exports = logToFile;